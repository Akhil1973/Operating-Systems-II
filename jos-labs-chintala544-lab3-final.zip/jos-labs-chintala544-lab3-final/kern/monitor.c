// Simple command-line kernel monitor useful for
// controlling the kernel and exploring the system interactively.

#include <inc/stdio.h>
#include <inc/string.h>
#include <inc/memlayout.h>
#include <inc/assert.h>
#include <inc/x86.h>

#include <kern/console.h>
#include <kern/monitor.h>
#include <kern/kdebug.h>

#include <kern/trap.h>

#include <kern/color.h>

#define CMDBUF_SIZE	80	// enough for one VGA text line


struct Command {
	const char *name;
	const char *desc;
	// return -1 to force monitor to exit
	int (*func)(int argc, char** argv, struct Trapframe* tf);
};

// LAB 1: add your command to here...
static struct Command commands[] = {
	{ "help", "Display this list of commands", mon_help },
	{ "kerninfo", "Display information about the kernel", mon_kerninfo },
	{ "show", "Display extra credit for lab1", mon_asciiart },
	{ "backtrace", "Display information about the kernel", mon_backtrace},


};

/***** Implementations of basic kernel monitor commands *****/

int
mon_help(int argc, char **argv, struct Trapframe *tf)
{
	int i;

	for (i = 0; i < ARRAY_SIZE(commands); i++)
		cprintf("%s - %s\n", commands[i].name, commands[i].desc);
	return 0;
}

int
mon_kerninfo(int argc, char **argv, struct Trapframe *tf)
{
	extern char _start[], entry[], etext[], edata[], end[];

	cprintf("Special kernel symbols:\n");
	cprintf("  _start                  %08x (phys)\n", _start);
	cprintf("  entry  %08x (virt)  %08x (phys)\n", entry, entry - KERNBASE);
	cprintf("  etext  %08x (virt)  %08x (phys)\n", etext, etext - KERNBASE);
	cprintf("  edata  %08x (virt)  %08x (phys)\n", edata, edata - KERNBASE);
	cprintf("  end    %08x (virt)  %08x (phys)\n", end, end - KERNBASE);
	cprintf("Kernel executable memory footprint: %dKB\n",
		ROUNDUP(end - entry, 1024) / 1024);
	return 0;
}

int
mon_backtrace(int argc, char **argv, struct Trapframe *tf)
{ 
	// LAB 1: Your code here.
    // HINT 1: use read_ebp().
    // HINT 2: print the current ebp on the first line (not current_ebp[0])
	cprintf("Stack Backtrace\n");
	struct Eipdebuginfo debuginfo;
	uint32_t *ebp = ((uint32_t *)read_ebp());
	int i;	
    while(ebp != '\0')
    { 
        debuginfo_eip(ebp[1] , &debuginfo);
		cprintf(" ebp %08x ", ebp); // current ebp
		for(i=1;i<=6;i++){   // traversing from ebp[1] -  ebp[6] as shown in the lab pdf.
			if(i==1){
			cprintf("eip %08x ", ebp[i]);
			cprintf("args ");
			}
			else
			cprintf("%08x ", ebp[i]);
		}
		cprintf("\n %s:%d: %.*s+%d \n",debuginfo.eip_file, debuginfo.eip_line,debuginfo.eip_fn_namelen,debuginfo.eip_fn_name,ebp[1] - debuginfo.eip_fn_addr);
		ebp =(uint32_t *)*ebp;
    }
	return 0;


	//Took help from TA Caden for doing this code and followed the procedure.
}

/***** Kernel monitor command interpreter *****/

#define WHITESPACE "\t\r\n "
#define MAXARGS 16

static int
runcmd(char *buf, struct Trapframe *tf)
{
	int argc;
	char *argv[MAXARGS];
	int i;

	// Parse the command buffer into whitespace-separated arguments
	argc = 0;
	argv[argc] = 0;
	while (1) {
		// gobble whitespace
		while (*buf && strchr(WHITESPACE, *buf))
			*buf++ = 0;
		if (*buf == 0)
			break;

		// save and scan past next arg
		if (argc == MAXARGS-1) {
			cprintf("Too many arguments (max %d)\n", MAXARGS);
			return 0;
		}
		argv[argc++] = buf;
		while (*buf && !strchr(WHITESPACE, *buf))
			buf++;
	}
	argv[argc] = 0;

	// Lookup and invoke the command
	if (argc == 0)
		return 0;
	for (i = 0; i < ARRAY_SIZE(commands); i++) {
		if (strcmp(argv[0], commands[i].name) == 0)
			return commands[i].func(argc, argv, tf);
	}
	cprintf("Unknown command '%s'\n", argv[0]);
	return 0;
}

void
monitor(struct Trapframe *tf)
{
	char *buf;

	cprintf("Welcome to the JOS kernel monitor!\n");
	cprintf("Type 'help' for a list of commands.\n");

	if (tf != NULL)
		print_trapframe(tf);

	while (1) {
		buf = readline("K> ");
		if (buf != NULL)
			if (runcmd(buf, tf) < 0)
				break;
	}
}

//ascii art code
int
mon_asciiart()
{
	//print art
	cprintf("printing \n");
	cprintf(blue"___________         __                                           .___.__  __\n"reset);
	cprintf(red"\\_   _____/__  ____/  |_____________      ___________   ____   __| _/|__|/  |_\n"reset);
	cprintf(green"|    __)_\\  \\/  /\\   __\\_  __ \\__  \\   _/ ___\\_  __ \\_/ __ \\ / __ | |  \\   __\n"reset);
	cprintf(yellow"|        \\>    <  |  |  |  | \\// __ \\_ \\  \\___|  | \\/\\  ___// /_/ | |  ||  |  \n"reset);
	cprintf(white"/_______  /__/\\_ \\ |__|  |__|  (____  /  \\___  >__|    \\___  >____ | |__||__|\n"reset);
	cprintf(magenta"|/_______/__/\\_ \\ |__|  |__|  (____  /  \\___  >__|    \\___  >____ | |__||__|  \n"reset);
	cprintf(cyan"        \\/      \\/                  \\/       \\/            \\/     \\/           \n"reset);
	return 0;

// prepared this from https://patorjk.com/software/taag/#p=display&f=Graffiti&t=Type%20Something%20	

}

